<html>
<head><title>CS 143 Project 2</title></head>
<body>
	<h1>Search</h1>
	<form action="search.php"> 
		<input type="text" name="query" placeholder="Search...">
		<button type="submit">Submit</button>
	</form>
</body>
</html>
